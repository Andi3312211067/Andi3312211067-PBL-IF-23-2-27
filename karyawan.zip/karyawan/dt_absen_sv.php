<?php
session_start();
include '../koneksi.php';

if (isset($_POST['simpan'])) {
    $id_karyawan = $_POST['id_karyawan'];
    $nama = $_POST['nama'];
    $waktu = $_POST['waktu'];

    // Mengambil data gambar dari input hidden
    $gambarData = $_POST['gambar'];

    // Menyimpan gambar ke direktori server
    $gambarPath = '../karyawan/img/' . time() . '.jpg'; // Ganti dengan path sesuai dengan kebutuhan Anda
    $gambarBase64 = str_replace('data:image/jpeg;base64,', '', $gambarData);
    $gambarDecoded = base64_decode($gambarBase64);
    file_put_contents($gambarPath, $gambarDecoded);

    // Menyimpan data ke database
    $save = "INSERT INTO tb_absen SET id_karyawan='$id_karyawan', nama='$nama', waktu='$waktu', gambar='$gambarPath'";
    $result = mysqli_query($koneksi, $save);

    if ($result) {
        echo json_encode(['message' => 'Data berhasil disimpan']);
    } else {
        echo json_encode(['message' => 'Gagal menyimpan data']);
    }
}
?>
